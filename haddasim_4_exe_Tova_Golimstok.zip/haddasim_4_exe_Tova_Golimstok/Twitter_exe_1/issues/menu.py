class Menu:
    @staticmethod
    def display():
        print("Select an option:")
        print("1. Rectangle")
        print("2. Triangular")
        print("3. Exit")

    @staticmethod
    def display_triangular_options():
        print("What do you want to do?")
        print("1. Calculate the perimeter of the triangle")
        print("2. Print the triangle")
