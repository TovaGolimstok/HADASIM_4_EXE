﻿using Microsoft.AspNetCore.Mvc;

namespace MyService.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProjectBaseController : ControllerBase
    {

    }
}
