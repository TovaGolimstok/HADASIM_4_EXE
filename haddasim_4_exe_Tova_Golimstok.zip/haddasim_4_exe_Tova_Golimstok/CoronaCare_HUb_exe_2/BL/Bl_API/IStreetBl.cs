﻿using BL.BLApi;
using BL.DTO_Models;

namespace BL.Bl_API
{
    public interface IStreetBl:IBl<StreetDTO>
    {

    }
}