﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BL.DTO_Models
{
    public class VaccineManufacturerDTO
    {
        public int ManufacturerId { get; set; }
        public string? ManufacturerName { get; set; }

    }
}
